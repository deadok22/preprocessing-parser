#ifdef A
int i;
#endif

void main() {
	i = 5;
}