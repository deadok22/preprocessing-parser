void foo(int i) {}

void main() {
	foo();
}