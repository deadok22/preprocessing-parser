void main() {
	int i = i;
}