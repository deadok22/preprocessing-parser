extern int sigpause (int __sig) __asm__ ("__xpg_sigpause");
main() {}