extern int *const bb_errno;
static const char test;
extern int fnmatch(const char *__pattern, int *__restrict __result_buf);
#if definedEx(CONFIG_FEATURE_TAR_LONG_OPTIONS)
static const char tar_longopts[] __attribute__((aligned(1))) =
	"list\0"
	;
#endif

void main() {
	int i;
	do {
		i = i + 1;
	} while (i < 5);
}