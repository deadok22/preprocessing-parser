static const char trailer[] __attribute__((aligned(1))) = "TRAILER!!!";

void main(){}