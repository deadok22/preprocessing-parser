
foo(unsigned int x)
{
  return (x << 1) | (x >> 31);
}
