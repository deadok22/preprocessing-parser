f(c){return!(c?2.0:1.0);}
