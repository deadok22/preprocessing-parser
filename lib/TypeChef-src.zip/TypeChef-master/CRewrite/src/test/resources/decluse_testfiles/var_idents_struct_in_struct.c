struct _IO_FILE;
struct _IO_FILE {
  int _flags;
  struct _IO_FILE *_chain;
};

void main() {}