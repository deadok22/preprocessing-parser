struct xz_dec {
	struct {
		enum {
			MISSING
		} sequence;
	} index;
};

void main() {}