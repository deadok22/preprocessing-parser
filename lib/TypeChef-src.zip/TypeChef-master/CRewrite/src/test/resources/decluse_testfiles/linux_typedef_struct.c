struct page;
typedef struct page *pgtable_t;

void main() {}