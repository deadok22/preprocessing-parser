enum xz_ret {
	XZ_BUF_ERROR
};

static  enum xz_ret  xz_dec_lzma2_run() {
	return null;
}

void main() {}