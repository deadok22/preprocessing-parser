typedef long int __off_t;

struct dirent {
	__off_t test;
};

void main() {}