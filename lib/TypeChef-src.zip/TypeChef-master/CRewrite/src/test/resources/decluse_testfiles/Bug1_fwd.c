int foo(){
    int i;
    i++;
    return i;
}
int foo(){
    foo();
}