
int main(a, b)
int a;
int b;
{
    a++;
    return b;
}