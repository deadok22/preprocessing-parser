typedef int new_int;
typedef struct {
	new_int int_name[sizeof (new_int)];
} fdset;

void main() {}