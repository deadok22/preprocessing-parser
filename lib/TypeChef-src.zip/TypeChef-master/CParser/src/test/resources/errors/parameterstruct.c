struct test {
    int a;
    int b;
}

struct test2 {
    int c;
    int d;
}

int getaddrinfo_a (int __mode, struct test *__list[20],
        int __ent, struct test2 *__restrict __sig);
