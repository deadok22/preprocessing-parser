#define X


main()
{
  for(;;
#ifdef Y
      )
#endif
	{
      }
}