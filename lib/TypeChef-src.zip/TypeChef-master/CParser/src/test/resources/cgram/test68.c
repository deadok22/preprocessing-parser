struct s
{
  int b;
};
struct s s = { .b = 3 }; 

