char *b = "a string with a \
continuation";

