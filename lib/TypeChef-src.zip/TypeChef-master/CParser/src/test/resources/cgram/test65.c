f()
{
    __label__ mylabel;
mylabel:
    goto mylabel;
}

