struct aaa_ {
int a;
int b;
} ;
typedef struct aaa_ aaa;
void foo (void *aaa);
void foo (void *paa)
{
    aaa *aab = (void *)paa;
    long *rtr; 
    char temptt;
    short *zzs;

}

