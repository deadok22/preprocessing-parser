typedef struct  h765t_  h765t  ;        
struct h765t_ {
void *ll881ss[10];
};
void gg (h765t *q23w3)
{
    if (q23w3->ll881ss[3]) {
       if (1) {
           q23w3->ll881ss[3] = (void *) (++(int)q23w3->ll881ss[3]);
       }
    }
}
