const typedef struct as340kj_ {
      short   t45e;
      char    *u76h;
} as340kj;
extern char *hh(char, as340kj*);

