typedef enum {
    F_FE,                        
    F_U,                         
    F_E,                 
} yy;
main() {
        exit(0);
}

