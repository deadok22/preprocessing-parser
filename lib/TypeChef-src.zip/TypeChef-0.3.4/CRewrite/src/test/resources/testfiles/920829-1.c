f(double x){double y;y=x/0.5;if(y<0.1)y=1.0;}
