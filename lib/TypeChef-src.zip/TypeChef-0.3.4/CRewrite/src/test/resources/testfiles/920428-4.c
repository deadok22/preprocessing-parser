x(a){struct{int p[a],i;}l;l.i;}
