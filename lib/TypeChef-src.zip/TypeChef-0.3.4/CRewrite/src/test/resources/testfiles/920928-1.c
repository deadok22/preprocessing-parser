struct{int c;}v;
static long i=((char*)&(v.c)-(char*)&v);
