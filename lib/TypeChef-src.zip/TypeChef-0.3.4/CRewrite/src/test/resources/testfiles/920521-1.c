/* { dg-do compile } */

f(){asm("f":::"cc");}g(x,y){asm("g"::"%r"(x), "r"(y));}
