joe()
{
  int j;

  while( 1 )
    {
      for( j = 0; j < 4; j++ )
	;
      for( j = 0; j < 4; j++ )
	;
    }
}
