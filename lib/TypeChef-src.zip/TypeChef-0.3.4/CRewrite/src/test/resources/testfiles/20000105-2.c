foo ()
{
  long long int i = (int) "";
}

