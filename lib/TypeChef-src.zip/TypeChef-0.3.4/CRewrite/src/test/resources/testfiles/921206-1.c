double sqrt(double),fabs(double),sin(double);
int sxs;
int sys;
f()
{
  int l;
  int sm = -52, sx = 52;
  char *smap;
  for (l = 0; l < 9; l++)
    {
      double g;
      int cx, cy, gx, gy, x, y;
      gx = 2 > g / 3 ? 2 : g / 3;
      gy = 2 > g / 3 ? 2 : g / 3;
      for (y = 0 > cy - gy ? 0 : cy - gy; y <= (sys - 1 < cy + gy ? sys : cy + gy); y++)
	{
	  int sx = 0 > cx - gx ? 0 : cx - gx;
	  short *ax = (short *) (y * sxs + sx);

	  for (x = sx; x <= (sxs - 1 < cx + gx ? sxs - 1 : cx + gx); x++)
	    {
	      double c=2.25, z=sqrt(fabs(1-c)), cz=(c>1?0.0:-10)>z?c>1?0:1:z;
	    }
	}
    }
  for (l = sm; l <= sx; l++)
    smap[l] = l > 0 ? 1 + foo(sin(.1 * l / sx)) : 1 - foo(sin(.1 * l / sm));
}
