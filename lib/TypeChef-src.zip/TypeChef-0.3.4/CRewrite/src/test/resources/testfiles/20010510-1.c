typedef char *ident;
#ident "This is ident"
ident i;
