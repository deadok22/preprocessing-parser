f(x, c)
{
  for (;;)
    {
      if (x << c) break;
      x++;
    }
}
