#ifndef NO_LABEL_VALUES
f(){static void*t[]={&&x};x:;}
#endif
g(){static unsigned p[5];}
