void f(int);
void f(x)unsigned char x;{}
