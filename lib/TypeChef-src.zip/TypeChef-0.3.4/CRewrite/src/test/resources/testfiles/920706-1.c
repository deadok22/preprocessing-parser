f(){float i[2],o[1];g(o);return*o;}
