long long f(long long a,long long b){return a<<b;}
