f(x){goto*(char)x;}
