struct{int c;}v;
static short i=((char*)&(v.c)-(char*)&v);
