#define ASIZE 0x100000000UL
#include "20031023-1.c"
