extern void malloc(__SIZE_TYPE__ size); 

toto()
{
    malloc(100);
}
