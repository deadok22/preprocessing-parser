x(a)double a;{int i;return i>a?i:i+1;}
