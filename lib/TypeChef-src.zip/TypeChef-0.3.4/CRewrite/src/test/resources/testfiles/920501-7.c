#ifndef NO_LABEL_VALUES
x(){if(&&e-&&b<0)x();b:goto*&&b;e:;}
#else
int x;
#endif
