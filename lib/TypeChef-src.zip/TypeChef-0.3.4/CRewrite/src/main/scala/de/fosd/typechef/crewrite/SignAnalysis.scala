package de.fosd.typechef.crewrite

trait SignAnalysis {

}
