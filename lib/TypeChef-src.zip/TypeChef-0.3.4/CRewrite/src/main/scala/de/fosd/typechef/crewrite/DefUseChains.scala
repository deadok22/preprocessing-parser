package de.fosd.typechef.crewrite

trait DefUseChains extends Variables {

}
