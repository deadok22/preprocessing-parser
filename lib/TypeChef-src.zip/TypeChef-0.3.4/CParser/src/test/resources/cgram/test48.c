typedef struct  g667h_  g667h  ;
struct g667h_ {
    const char *ttc;
    const char *e;
    const char *t;
};


int dddd(char *yt5,
         g667h *g667h);
int dddd(char *yt5,
         g667h *g667h)
{

int  ttt;

}

