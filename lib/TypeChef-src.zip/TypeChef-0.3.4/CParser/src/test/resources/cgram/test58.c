g ();
f ()
{
  int seed;
  g (seed);
}

