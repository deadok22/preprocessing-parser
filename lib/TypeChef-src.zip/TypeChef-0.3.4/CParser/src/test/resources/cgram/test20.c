      foo (float f, float g)
      {
        float beat_freqs[2] = { f-g, f+g };
        return 1;
     }
    
