extern void rt(long, long);
extern long rn(void);
extern void rl(char*, int, int);
int    rd  (void **, int)  ;
rf (int *rnx)
{
                return (rnx);
}

rnn (int rny)
{
                return (rny);
}
 ;                               
 ;
extern const int XYZ ; ;
 ;

