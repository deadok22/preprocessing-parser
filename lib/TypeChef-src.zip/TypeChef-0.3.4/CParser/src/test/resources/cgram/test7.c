typedef int A, B(A);

