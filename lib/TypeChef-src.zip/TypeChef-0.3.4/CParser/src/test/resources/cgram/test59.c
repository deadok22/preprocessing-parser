typedef long time_t;

static time_t
f (janfirst, rulep)
     __const time_t janfirst;
     register __const int * __const rulep;
{
}

