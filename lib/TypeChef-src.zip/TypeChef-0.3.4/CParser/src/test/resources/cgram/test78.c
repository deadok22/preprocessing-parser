# 1 "test78.c"

# 1 "a.h" 1

int aa1;
int aa2;
void testaa(void);
# 2 "test78.c" 2

# 1 "b.h" 1

int bb1;
int bb2;
# 1 "b1.h" 1

int b12;
int b22;
# 1 "b12.h" 1

int b33;
# 1 "b13.h" 1

int b44;

# 1 "b14.h" 1
int r45;
void ttt(void);
int r56;
# 4 "b13.h" 2


int b55;
# 3 "b12.h" 2

void test66(void);
# 4 "b1.h" 2

void testb12(void);
# 4 "b.h" 2

int bb3;



# 3 "test78.c" 2

# 1 "c.h" 1

int c11;
int c12;
void testc1(void);
# 4 "test78.c" 2

