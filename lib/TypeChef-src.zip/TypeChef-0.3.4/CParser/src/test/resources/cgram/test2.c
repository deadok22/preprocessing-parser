int test2;
#line 37 "uhhuh.c"
#line 10 "input.c"
int i;
int *i;

/*  
    this is a comment
    #line 50 
    with a line directive in it,
    very annoying
    */

typedef long mylong;

enum myenum { one, two, three };

# 32 "gnustyle.h" 1 3 4
// old style
short foo(a, c)
  short a;
  char c;
{   return 3;
}

#line 100 
int f(char c, char *d)
{

  struct s;
  int z = 100;
  struct s { 
    short c, d;
    long l;
    mylong m;
  };


}

