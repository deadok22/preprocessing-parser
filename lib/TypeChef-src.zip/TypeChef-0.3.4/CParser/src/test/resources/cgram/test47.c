typedef struct  g667h_  g667h  ;
struct g667h_ {
    const char *ttc;
    const char *e;
    const char *t;
};


int dddd()
{

int g667h, ttt;

}

