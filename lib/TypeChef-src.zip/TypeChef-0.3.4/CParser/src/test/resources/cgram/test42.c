typedef struct  checkme_  checkme  ;

typedef struct yt668u_ {
        int             j76g;    
        int             lk4f2s;          
        int             hg62;
} yt668u;

void
a233 (yt668u *checkme)
{ 
    if ((( checkme )->j76g) ) {
    }
        {
                  { (  ( checkme )->lk4f2s  )  = 0; } ;  
          ( checkme )->hg62 = 0;
          } 
    ;
}


