main() {
    int a;
    typedef b = (a);
    typeof (int *) c;
    typeof (d[0](1)) e;
    c = &a;
}
