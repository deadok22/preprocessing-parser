
typedef struct a {
        int b;
        } c,*d;

extern int execv(const char *, char *const []);
int b;
int a = b = 1;
static char *predefs = "whatever \
more ";
char *temporary_firstobj = 
(char *) __extension__       
({ struct obstack *__h = ( &temporary_obstack ); 
       __extension__   ({ struct obstack *__o = ( __h );
       int __len = (  (  0 ) );
        if (__o->chunk_limit - __o->next_free < __len)  _obstack_newchunk (__o, __len); __o->next_free += __len;        (void) 0; }) ;  __extension__   ({ struct obstack *__o1 = ( __h );      void *value;    value = (void *) __o1->object_base;     if (__o1->next_free == value)   __o1->maybe_empty_object = 1;   __o1->next_free = (( ((( __o1->next_free ) - (char *) 0) +__o1->alignment_mask) & ~ (__o1->alignment_mask) ) + (char *) 0) ;    if (__o1->next_free - (char *)__o1->chunk       > __o1->chunk_limit - (char *)__o1->chunk)      __o1->next_free = __o1->chunk_limit;    __o1->object_base = __o1->next_free;    value; }) ; }) ;

static char cPickle_module_documentation[] = 
"C implementation and optimization of the Python pickle module\n"
"\n"
"cPickle.c,v 1.48 1997/12/07 14:37:39 jim Exp\n"
;

