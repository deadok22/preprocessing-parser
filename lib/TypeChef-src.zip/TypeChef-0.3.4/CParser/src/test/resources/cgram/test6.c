typedef char F;
main() {
        long a=sizeof(F), F, b=sizeof(F);
        //assert(1 == a);
        //assert(sizeof(long) == b);
        }

