int x;

int y;

test(){
switch (x) {
 case 1: y=3;
    break;
 case 2: y=90;
    break;
 default:
}
}

