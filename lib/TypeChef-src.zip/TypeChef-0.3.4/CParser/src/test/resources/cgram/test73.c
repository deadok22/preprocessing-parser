f()
{
  __label__ lbl1;
  __label__ lbl2;

lbl1:;
lbl2:;

}

