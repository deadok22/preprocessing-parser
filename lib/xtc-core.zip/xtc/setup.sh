JAVA_DEV_ROOT=~/xtc
CLASSPATH=~/xtc/classes:~/xtc/bin/junit.jar:~/xtc/bin/javabdd.jar
JAVA_HOME=/usr/bin
PATH_SEP=:
export JAVA_DEV_ROOT CLASSPATH JAVA_HOME PATH_SEP
