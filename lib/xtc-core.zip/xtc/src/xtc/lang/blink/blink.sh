#!/bin/bash

exec java -ea xtc.lang.blink.Blink $*
