#ifndef _AGENT_MAIN_H_
#define _AGENT_MAIN_H_

extern JavaVM * bda_jvm;
extern jvmtiEnv * bda_jvmti;
extern jniNativeInterface* bda_orig_jni_funcs;

#endif /* _AGENT_MAIN_H_ */
