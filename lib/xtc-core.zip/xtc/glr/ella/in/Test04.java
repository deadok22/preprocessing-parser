static {
  Sbox = new byte[8][16];
}
