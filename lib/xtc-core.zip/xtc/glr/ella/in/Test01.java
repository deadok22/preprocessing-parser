// A very simple class
public class Test01 {
}
