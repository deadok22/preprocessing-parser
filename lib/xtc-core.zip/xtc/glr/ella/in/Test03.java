static {
  foo((Element)(bar));
}
